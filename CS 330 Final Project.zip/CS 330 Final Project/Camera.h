#pragma once
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

enum class Camera_Movement { FORWARD, BACKWARD, LEFT, RIGHT, UP, DOWN };

class Camera {
public:
    // state
    glm::vec3 Position;
    glm::vec3 Front;
    glm::vec3 Up;
    glm::vec3 Right;
    glm::vec3 WorldUp;

    // euler
    float Yaw;    // degrees
    float Pitch;  // degrees

    // options
    float MovementSpeed;     // units / second
    float MouseSensitivity;  // degrees per pixel
    float Zoom;              // fov for perspective

    Camera(glm::vec3 position = { 0.0f, 1.2f, 4.0f },
        glm::vec3 up = { 0.0f, 1.0f, 0.0f },
        float yaw = -90.0f, float pitch = 0.0f)
        : Position(position), WorldUp(up), Yaw(yaw), Pitch(pitch),
        MovementSpeed(3.0f), MouseSensitivity(0.12f), Zoom(45.0f)
    {
        updateVectors();
    }

    glm::mat4 GetViewMatrix() const {
        return glm::lookAt(Position, Position + Front, Up);
    }

    void ProcessKeyboard(Camera_Movement dir, float deltaTime) {
        float velocity = MovementSpeed * deltaTime;
        if (dir == Camera_Movement::FORWARD)  Position += Front * velocity;
        if (dir == Camera_Movement::BACKWARD) Position -= Front * velocity;
        if (dir == Camera_Movement::LEFT)     Position -= Right * velocity;
        if (dir == Camera_Movement::RIGHT)    Position += Right * velocity;
        if (dir == Camera_Movement::UP)       Position += WorldUp * velocity;
        if (dir == Camera_Movement::DOWN)     Position -= WorldUp * velocity;
    }

    void ProcessMouseMovement(float xoffset, float yoffset, bool constrainPitch = true) {
        xoffset *= MouseSensitivity;
        yoffset *= MouseSensitivity;

        Yaw += xoffset;
        Pitch += yoffset;

        if (constrainPitch) {
            if (Pitch > 89.0f)  Pitch = 89.0f;
            if (Pitch < -89.0f) Pitch = -89.0f;
        }
        updateVectors();
    }

    void ProcessMouseScroll(float yoffset) {
        // use scroll to scale speed (rubric: adjust movement speed)
        // clamp between 0.5 and 20
        MovementSpeed += yoffset * 0.5f;
        if (MovementSpeed < 0.5f) MovementSpeed = 0.5f;
        if (MovementSpeed > 20.0f) MovementSpeed = 20.0f;
    }

    // Helpers to snap for orthographic view (front-on)
    void SnapFrontView(glm::vec3 target, float distance, float height) {
        Pitch = 0.0f;
        Yaw = -90.0f; // looking along -Z with GLM default
        Position = glm::vec3(target.x, height, target.z + distance);
        updateVectors();
    }

private:
    void updateVectors() {
        glm::vec3 front;
        front.x = cosf(glm::radians(Yaw)) * cosf(glm::radians(Pitch));
        front.y = sinf(glm::radians(Pitch));
        front.z = sinf(glm::radians(Yaw)) * cosf(glm::radians(Pitch));
        Front = glm::normalize(front);
        Right = glm::normalize(glm::cross(Front, WorldUp));
        Up = glm::normalize(glm::cross(Right, Front));
    }
};
