﻿///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the loading and rendering of 3D scenes
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <iostream>
#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0, height = 0, colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (image)
    {
        std::cout << "Successfully loaded image: " << filename
            << ", width:" << width << ", height:" << height
            << ", channels:" << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // wrapping & filtering
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels\n";
            stbi_image_free(image);
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;
        return true;
    }

    std::cout << "Could not load image: " << filename << std::endl;
    return false;
}

/***********************************************************
 *  BindGLTextures()
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        glGenTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  FindTextureID()
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else
            index++;
    }

    return textureID;
}

/***********************************************************
 *  FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureSlot = index;
            bFound = true;
        }
        else
            index++;
    }

    return textureSlot;
}

/***********************************************************
 *  FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0) return false;

    int index = 0;
    bool bFound = false;
    while ((index < (int)m_objectMaterials.size()) && (bFound == false))
    {
        if (m_objectMaterials[index].tag.compare(tag) == 0)
        {
            bFound = true;
            material.ambientColor = m_objectMaterials[index].ambientColor;
            material.ambientStrength = m_objectMaterials[index].ambientStrength;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            index++;
        }
    }

    return true;
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 modelView(1.0f);
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(redColorValue, greenColorValue, blueColorValue, alphaValue);

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        int textureSlot = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/***********************************************************
 *  SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    if (m_objectMaterials.size() > 0)
    {
        OBJECT_MATERIAL material;
        bool ok = FindMaterial(materialTag, material);
        if (ok)
        {
            m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
            m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Load once per mesh type
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();        // bench slats/legs/arms/supports
    m_basicMeshes->LoadCylinderMesh();   // bolts / poles
    m_basicMeshes->LoadConeMesh();       // lamppost cap, etc.
    m_basicMeshes->LoadSphereMesh();     // lamppost bulb, etc.

    // Try multiple locations for wood texture (tag: "wood")
    const char* woodCandidates[] = {
        "../../Utilities/textures/wood.jpg",
        "..\\..\\Utilities\\textures\\wood.jpg",
        "../../../Utilities/textures/wood.jpg",
        "..\\..\\..\\Utilities\\textures\\wood.jpg",
        "textures/wood.jpg",
        "Utilities/textures/wood.jpg",
        "Utilities\\textures\\wood.jpg"
    };

    bool woodLoaded = false;
    for (auto p : woodCandidates) {
        if (CreateGLTexture(p, "wood")) { woodLoaded = true; break; }
    }
    if (!woodLoaded)
        std::cout << "[WARN] Wood texture not found in fallback paths. Using solid colors instead.\n";

    // Try multiple locations for metal texture (tag: "metal")
    const char* metalCandidates[] = {
        "../../Utilities/textures/metal.jpg",
        "..\\..\\Utilities\\textures\\metal.jpg",
        "../../../Utilities/textures/metal.jpg",
        "..\\..\\..\\Utilities\\textures\\metal.jpg",
        "textures/metal.jpg",
        "Utilities/textures/metal.jpg",
        "Utilities\\textures\\metal.jpg"
    };

    bool metalLoaded = false;
    for (auto p : metalCandidates) {
        if (CreateGLTexture(p, "metal")) { metalLoaded = true; break; }
    }
    if (!metalLoaded)
        std::cout << "[WARN] Metal texture not found in fallback paths. Using solid colors instead.\n";

    // Bind textures so sampler slots line up for rendering
    BindGLTextures();
}


/***********************************************************
 *  RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
    // Common transform vars
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    /***************** GROUND PLANE — LIT (Phong) *****************/
    scaleXYZ = glm::vec3(12.0f, 1.0f, 8.0f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue("bUseLighting", true);
        m_pShaderManager->setIntValue("bUseTexture", false);

        // Slightly gray so colored light shows
        m_pShaderManager->setVec4Value("objectColor", glm::vec4(0.85f, 0.86f, 0.90f, 1.0f));
        // Make lighting obvious: low ambient, bright specular, tighter highlight
        m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(1.0f));
        m_pShaderManager->setFloatValue("material.ambientStrength", 0.08f);
        m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f));
        m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
        m_pShaderManager->setFloatValue("material.shininess", 64.0f);
        m_pShaderManager->setFloatValue("UVrotation", 0.0f);
    }
    m_basicMeshes->DrawPlaneMesh();

    /***************** Helpers *****************/
    auto UseWood = [&]() {
        // Bench: lit + textured wood (fallback to brown color)
        if (m_pShaderManager) {
            m_pShaderManager->setIntValue("bUseLighting", true);
            if (FindTextureSlot("wood") >= 0) {
                m_pShaderManager->setIntValue("bUseTexture", true);
                SetShaderTexture("wood");
            }
            else {
                m_pShaderManager->setIntValue("bUseTexture", false);
                SetShaderColor(0.45f, 0.28f, 0.16f, 1.0f);
            }
            // Wood material: subtle specular
            m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(1.0f));
            m_pShaderManager->setFloatValue("material.ambientStrength", 0.12f);
            m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f));
            m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.25f));
            m_pShaderManager->setFloatValue("material.shininess", 16.0f);
        }
        };
    auto UseMetal = [&]() {
        // Metal props: lit + metal texture (fallback to gray color)
        if (m_pShaderManager) {
            m_pShaderManager->setIntValue("bUseLighting", true);
            if (FindTextureSlot("metal") >= 0) {
                m_pShaderManager->setIntValue("bUseTexture", true);
                SetShaderTexture("metal");
            }
            else {
                m_pShaderManager->setIntValue("bUseTexture", false);
                SetShaderColor(0.70f, 0.72f, 0.75f, 1.0f);
            }
            // Brighter specular for metal
            m_pShaderManager->setVec3Value("material.ambientColor", glm::vec3(1.0f));
            m_pShaderManager->setFloatValue("material.ambientStrength", 0.10f);
            m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(0.95f));
            m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.60f));
            m_pShaderManager->setFloatValue("material.shininess", 32.0f);
        }
        };
    auto UV = [&](float u, float v, float rotDeg) {
        SetTextureUVScale(u, v);
        if (m_pShaderManager) m_pShaderManager->setFloatValue("UVrotation", glm::radians(rotDeg));
        };

    /***************** BENCH — LIT (textured) *****************/
    const float S = 3.0f;      // overall bench scale
    const float liftY = 0.10f;     // lift above plane to avoid z-fighting
    const float benchYaw = 5.0f;      // slight yaw
    const float seatSlatY = 0.07f * S;
    const float backSlatY = 0.06f * S;
    const float backTilt = -5.0f;
    const float legSpacing = 0.95f * S;

    // Seat slats (3)
    UseWood(); UV(4.0f, 1.0f, 0.0f);
    scaleXYZ = glm::vec3(2.0f * S, seatSlatY, 0.35f * S);
    XrotationDegrees = 0.0f; YrotationDegrees = benchYaw; ZrotationDegrees = 0.0f;

    positionXYZ = glm::vec3(0.0f, (0.50f * S) + liftY, -0.10f * S);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    positionXYZ = glm::vec3(0.0f, (0.57f * S) + liftY, 0.00f * S);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    positionXYZ = glm::vec3(0.0f, (0.50f * S) + liftY, 0.10f * S);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    // Front seat beam
    UseWood(); UV(3.0f, 1.0f, 0.0f);
    scaleXYZ = glm::vec3(2.0f * S, 0.08f * S, 0.10f * S);
    positionXYZ = glm::vec3(0.0f, (0.45f * S) + liftY, 0.18f * S);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    // Legs (2) – grain vertical
    UseWood(); UV(2.0f, 1.0f, 90.0f);
    scaleXYZ = glm::vec3(0.10f * S, 0.55f * S, 0.55f * S);

    positionXYZ = glm::vec3(-legSpacing, (scaleXYZ.y * 0.5f) + liftY, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, benchYaw, 0.0f, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    positionXYZ = glm::vec3(legSpacing, (scaleXYZ.y * 0.5f) + liftY, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, benchYaw, 0.0f, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    // Back supports (2) – grain vertical
    UseWood(); UV(2.0f, 1.0f, 90.0f);
    scaleXYZ = glm::vec3(0.08f * S, 0.65f * S, 0.10f * S);

    positionXYZ = glm::vec3(-legSpacing, (0.80f * S) + liftY, -0.28f * S);
    SetTransformations(scaleXYZ, 0.0f, benchYaw, 0.0f, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    positionXYZ = glm::vec3(legSpacing, (0.80f * S) + liftY, -0.28f * S);
    SetTransformations(scaleXYZ, 0.0f, benchYaw, 0.0f, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    // Back slats (3)
    UseWood(); UV(4.0f, 1.0f, 0.0f);
    scaleXYZ = glm::vec3(2.0f * S, backSlatY, 0.25f * S);
    XrotationDegrees = backTilt; YrotationDegrees = benchYaw;

    positionXYZ = glm::vec3(0.0f, (0.88f * S) + liftY, -0.38f * S);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, 0.0f, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    positionXYZ = glm::vec3(0.0f, (0.98f * S) + liftY, -0.38f * S);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, 0.0f, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    positionXYZ = glm::vec3(0.0f, (1.08f * S) + liftY, -0.38f * S);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, 0.0f, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    /******** LAMPPOST (RIGHT) — grounded by half-height, cap/bulb at true top ********/
    {
        // Ensure metal shading (no wood)
        m_pShaderManager->setIntValue("bUseTexture", false);
        SetShaderColor(0.16f, 0.16f, 0.18f, 1.0f);
        m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
        m_pShaderManager->setFloatValue("material.shininess", 64.0f);

        const float yaw = 5.0f;
        const float xPos = 8.0f;
        const float zPos = 0.0f;

        // One knob to fix “floating” or “sinking” once and for all (start at 0.0f).
        // If it still floats, make this a little NEGATIVE (e.g., -0.08f).
        // If it sinks, make it slightly POSITIVE (e.g., +0.02f).
        const float GROUND_BIAS = -0.08f;

        // ---- POLE (cylinder) ----
        const float poleH = 5.0f;   // scale.y
        const float poleR = 0.60f;  // scale.x/z
        glm::vec3 poleScale(poleR, poleH, poleR);

        const float poleHalf = poleScale.y * 0.5f;
        const float poleCenterY = poleHalf + GROUND_BIAS;     // sits on the plane
        const float poleTopY = poleCenterY + poleHalf;     // true top of the pole

        SetTransformations(poleScale, 0.0f, yaw, 0.0f, glm::vec3(xPos, poleCenterY, zPos));
        m_basicMeshes->DrawCylinderMesh();

        // ---- Base disk (optional visual base) ----
        glm::vec3 baseScale(poleR * 1.6f, 0.12f, poleR * 1.6f);
        const float baseCenterY = (baseScale.y * 0.5f) + GROUND_BIAS;
        SetTransformations(baseScale, 0.0f, yaw, 0.0f, glm::vec3(xPos, baseCenterY, zPos));
        m_basicMeshes->DrawCylinderMesh();

        // ---- CAP (cone) at the TRUE top ----
        const float capH = 1.20f, capR = 1.10f;
        glm::vec3 capScale(capR, capH, capR);
        const float capCenterY = poleTopY + (capH * 2.5f);
        SetTransformations(capScale, 0.0f, yaw, 0.0f, glm::vec3(xPos, capCenterY, zPos));
        m_basicMeshes->DrawConeMesh();

        // ---- BULB (sphere) above cap ----
        SetShaderColor(1.0f, 0.98f, 0.85f, 1.0f);            // warm bulb
        const float bulbR = 0.90f;
        glm::vec3 bulbScale(bulbR);
        const float bulbCenterY = poleTopY + capH + bulbR;
        SetTransformations(bulbScale, 0.0f, yaw, 0.0f, glm::vec3(xPos, bulbCenterY, zPos));
        m_basicMeshes->DrawSphereMesh();

    }

    /******** TRASH CAN (LEFT) — grounded by half-height ********/
    {
        m_pShaderManager->setIntValue("bUseTexture", false);
        SetShaderColor(0.35f, 0.35f, 0.40f, 1.0f);
        m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f));
        m_pShaderManager->setFloatValue("material.shininess", 32.0f);

        const float yaw = 5.0f;
        const float xPos = -8.0f;
        const float zPos = 0.0f;

        // Use the SAME bias so it sits exactly like the pole.
        const float GROUND_BIAS = -1.50f;

        const float canH = 3.00f;
        const float canR = 1.20f;
        glm::vec3 canScale(canR, canH, canR);

        const float canHalf = canScale.y * 0.5f;
        const float canCenterY = canHalf + GROUND_BIAS;
        SetTransformations(canScale, 0.0f, yaw, 0.0f, glm::vec3(xPos, canCenterY, zPos));
        m_basicMeshes->DrawCylinderMesh();

        // Rim on top (thin box)
        const float rimT = 0.12f;
        glm::vec3 rimScale(canR * 1.50f, rimT, canR * 1.50f);
        const float rimCenterY = (canCenterY + canHalf) + (rimT * 0.5f);
        SetTransformations(rimScale, 0.0f, yaw, 0.0f, glm::vec3(xPos, rimCenterY, zPos));
        m_basicMeshes->DrawBoxMesh();
    }


}
