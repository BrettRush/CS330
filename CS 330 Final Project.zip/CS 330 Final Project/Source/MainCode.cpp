#include <iostream>
#include <cstdlib>

#include <GL/glew.h>
#include "GLFW/glfw3.h"

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

// ====================== Camera helpers ======================
enum class CamMove { Forward, Backward, Left, Right, Up, Down };

struct FpsCamera {
    glm::vec3 Position{ 0.0f, 1.2f, 6.0f };
    glm::vec3 Front{ 0.0f, 0.0f, -1.0f };
    glm::vec3 Up{ 0.0f, 1.0f,  0.0f };
    glm::vec3 Right{ 1.0f, 0.0f,  0.0f };
    glm::vec3 WorldUp{ 0.0f, 1.0f,  0.0f };

    float Yaw = -90.0f;
    float Pitch = -5.0f;
    float MoveSpeed = 3.0f;
    float MouseSensitivity = 0.12f;
    float FovDegrees = 45.0f;

    glm::mat4 View() const { return glm::lookAt(Position, Position + Front, Up); }

    void ProcessKeyboard(CamMove dir, float dt) {
        float v = MoveSpeed * dt;
        if (dir == CamMove::Forward)  Position += Front * v;
        if (dir == CamMove::Backward) Position -= Front * v;
        if (dir == CamMove::Left)     Position -= Right * v;
        if (dir == CamMove::Right)    Position += Right * v;
        if (dir == CamMove::Up)       Position += WorldUp * v;
        if (dir == CamMove::Down)     Position -= WorldUp * v;
    }
    void ProcessMouse(float dx, float dy) {
        dx *= MouseSensitivity; dy *= MouseSensitivity;
        Yaw += dx; Pitch += dy;
        if (Pitch > 89.0f)  Pitch = 89.0f;
        if (Pitch < -89.0f) Pitch = -89.0f;
        updateVectors();
    }
    void ProcessScroll(double yoff) {
        MoveSpeed += float(yoff) * 0.5f;
        if (MoveSpeed < 0.5f) MoveSpeed = 0.5f;
        if (MoveSpeed > 20.0f) MoveSpeed = 20.0f;
    }
    void SnapFrontOrtho(const glm::vec3& target, float dist, float height) {
        Pitch = 0.0f; Yaw = -90.0f;
        Position = glm::vec3(target.x, height, target.z + dist);
        updateVectors();
    }
    void updateVectors() {
        glm::vec3 f;
        f.x = cosf(glm::radians(Yaw)) * cosf(glm::radians(Pitch));
        f.y = sinf(glm::radians(Pitch));
        f.z = sinf(glm::radians(Yaw)) * cosf(glm::radians(Pitch));
        Front = glm::normalize(f);
        Right = glm::normalize(glm::cross(Front, WorldUp));
        Up = glm::normalize(glm::cross(Right, Front));
    }
};

// ====================== Globals ======================
namespace {
    const char* const WINDOW_TITLE = "7-1 FinalProject and Milestones";
    GLFWwindow* g_Window = nullptr;
    SceneManager* g_SceneManager = nullptr;
    ShaderManager* g_ShaderManager = nullptr;
    ViewManager* g_ViewManager = nullptr;

    FpsCamera gCam;
    bool  gUsePerspective = true;
    bool  gFirstMouse = true;
    bool  gMouseCaptured = true;
    double gLastX = 640.0, gLastY = 360.0;
    float gDeltaTime = 0.0f, gLastFrame = 0.0f;

    const glm::vec3 kBenchTarget(0.0f, 0.9f, 0.0f);
}

// Decls
bool InitializeGLFW();
bool InitializeGLEW();

// Uniform helpers
static void SetViewProjUniforms(ShaderManager* sh, const glm::mat4& view, const glm::mat4& proj)
{
    sh->use();
    sh->setMat4Value("view", view);
    sh->setMat4Value("projection", proj);
    sh->setMat4Value("viewTransform", view);
    sh->setMat4Value("projectionTransform", proj);
}
static void SetCameraUniforms(ShaderManager* sh, const glm::vec3& eye)
{
    sh->use();
    sh->setVec3Value("cameraPosition", eye);
    sh->setVec3Value("viewPos", eye);
}

// Callbacks
static void FramebufferSizeCallback(GLFWwindow*, int w, int h) { glViewport(0, 0, w, h); }
static void CursorPosCallback(GLFWwindow*, double xpos, double ypos)
{
    if (!gMouseCaptured) return;
    if (gFirstMouse) { gLastX = xpos; gLastY = ypos; gFirstMouse = false; }
    float dx = float(xpos - gLastX), dy = float(gLastY - ypos);
    gLastX = xpos; gLastY = ypos;
    gCam.ProcessMouse(dx, dy);
}
static void ScrollCallback(GLFWwindow*, double, double yoff) { gCam.ProcessScroll(yoff); }
static void KeyCallback(GLFWwindow* window, int key, int, int action, int)
{
    if (action == GLFW_PRESS) {
        if (key == GLFW_KEY_P) { gUsePerspective = true; gCam.Position = { 0,1.2f,6 }; gCam.Yaw = -90; gCam.Pitch = -5; gCam.updateVectors(); }
        if (key == GLFW_KEY_O) { gUsePerspective = false; gCam.SnapFrontOrtho(kBenchTarget, 3.0f, 0.9f); }
        if (key == GLFW_KEY_ESCAPE) {
            if (gMouseCaptured) { gMouseCaptured = false; glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL); gFirstMouse = true; }
            else { glfwSetWindowShouldClose(window, true); }
        }
        if (key == GLFW_KEY_F1) {
            gMouseCaptured = !gMouseCaptured;
            glfwSetInputMode(window, GLFW_CURSOR, gMouseCaptured ? GLFW_CURSOR_DISABLED : GLFW_CURSOR_NORMAL);
            gFirstMouse = true;
        }
    }
}
static void ProcessMovement(GLFWwindow* w)
{
    if (glfwGetKey(w, GLFW_KEY_W) == GLFW_PRESS) gCam.ProcessKeyboard(CamMove::Forward, gDeltaTime);
    if (glfwGetKey(w, GLFW_KEY_S) == GLFW_PRESS) gCam.ProcessKeyboard(CamMove::Backward, gDeltaTime);
    if (glfwGetKey(w, GLFW_KEY_A) == GLFW_PRESS) gCam.ProcessKeyboard(CamMove::Left, gDeltaTime);
    if (glfwGetKey(w, GLFW_KEY_D) == GLFW_PRESS) gCam.ProcessKeyboard(CamMove::Right, gDeltaTime);
    if (glfwGetKey(w, GLFW_KEY_E) == GLFW_PRESS) gCam.ProcessKeyboard(CamMove::Up, gDeltaTime);
    if (glfwGetKey(w, GLFW_KEY_Q) == GLFW_PRESS) gCam.ProcessKeyboard(CamMove::Down, gDeltaTime);
}

// ====================== Main ======================
int main(int, char**)
{
    if (!InitializeGLFW()) return EXIT_FAILURE;

    g_ShaderManager = new ShaderManager();
    g_ViewManager = new ViewManager(g_ShaderManager);

    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);
    if (!g_Window) { std::cerr << "Failed to create GLFW window\n"; return EXIT_FAILURE; }

    glfwSetFramebufferSizeCallback(g_Window, FramebufferSizeCallback);
    glfwSetCursorPosCallback(g_Window, CursorPosCallback);
    glfwSetScrollCallback(g_Window, ScrollCallback);
    glfwSetKeyCallback(g_Window, KeyCallback);
    glfwSetInputMode(g_Window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    gMouseCaptured = true; gFirstMouse = true;

    if (!InitializeGLEW()) return EXIT_FAILURE;

    g_ShaderManager->LoadShaders("../../Utilities/shaders/vertexShader.glsl",
        "../../Utilities/shaders/fragmentShader.glsl");
    g_ShaderManager->use();

    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();

    int fbw = 0, fbh = 0;
    glfwGetFramebufferSize(g_Window, &fbw, &fbh);
    glViewport(0, 0, fbw, fbh);

    glDisable(GL_CULL_FACE);
    glEnable(GL_DEPTH_TEST);

    while (!glfwWindowShouldClose(g_Window))
    {
        float now = float(glfwGetTime());
        gDeltaTime = now - gLastFrame; gLastFrame = now;

        ProcessMovement(g_Window);

        glClearColor(0.05f, 0.05f, 0.06f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        g_ShaderManager->use();

        // VIEW / PROJECTION
        glm::mat4 view = gCam.View();
        glfwGetFramebufferSize(g_Window, &fbw, &fbh);
        float aspect = (fbh > 0) ? float(fbw) / float(fbh) : 16.0f / 9.0f;

        glm::mat4 proj(1.0f);
        if (gUsePerspective)
            proj = glm::perspective(glm::radians(gCam.FovDegrees), aspect, 0.1f, 100.0f);
        else {
            float h = 1.1f, w = h * aspect;
            proj = glm::ortho(-w, w, -h, h, 0.1f, 100.0f);
        }

        SetViewProjUniforms(g_ShaderManager, view, proj);
        SetCameraUniforms(g_ShaderManager, gCam.Position);

        // ---------- Lights ----------
        float t = now * 0.7f;

        // Dim directional white (fill)
        g_ShaderManager->setVec3Value("dirLight.direction", glm::vec3(-0.4f, -1.0f, -0.3f));
        g_ShaderManager->setVec3Value("dirLight.color", glm::vec3(0.35f, 0.35f, 0.40f));

        // Warm amber point light moving in a circle (ground hotspot)
        glm::vec3 plPos(
            0.6f * cosf(t),
            0.28f,
            0.6f * sinf(t)
        );
        g_ShaderManager->setVec3Value("pointLight.position", plPos);
        g_ShaderManager->setVec3Value("pointLight.color", glm::vec3(1.00f, 0.78f, 0.45f));
        g_ShaderManager->setFloatValue("pointLight.constant", 1.0f);
        g_ShaderManager->setFloatValue("pointLight.linear", 0.9f);
        g_ShaderManager->setFloatValue("pointLight.quadratic", 2.2f);

        // Cool white point light shining on the bench
        glm::vec3 benchLightPos(0.8f, 1.0f, 0.6f);
        g_ShaderManager->setVec3Value("pointLight2.position", benchLightPos);
        g_ShaderManager->setVec3Value("pointLight2.color", glm::vec3(0.90f, 0.95f, 1.00f));
        g_ShaderManager->setFloatValue("pointLight2.constant", 1.0f);
        g_ShaderManager->setFloatValue("pointLight2.linear", 0.35f);
        g_ShaderManager->setFloatValue("pointLight2.quadratic", 0.44f);
        // ---------------------------------------------------

        g_SceneManager->RenderScene();

        glfwSwapBuffers(g_Window);
        glfwPollEvents();
    }

    delete g_SceneManager; g_SceneManager = nullptr;
    delete g_ViewManager;  g_ViewManager = nullptr;
    delete g_ShaderManager;g_ShaderManager = nullptr;

    return EXIT_SUCCESS;
}

// ====================== Init helpers ======================
bool InitializeGLFW()
{
    glfwInit();
#ifdef __APPLE__
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif
    return true;
}
bool InitializeGLEW()
{
    GLenum res = glewInit();
    if (res != GLEW_OK) { std::cerr << glewGetErrorString(res) << std::endl; return false; }
    std::cout << "INFO: OpenGL Successfully Initialized\n";
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n\n";
    return true;
}
