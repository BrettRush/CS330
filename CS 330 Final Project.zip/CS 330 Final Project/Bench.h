﻿#pragma once
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

// --- OpenGL header (your template uses either glad or GLEW). This picks what's present.
#if __has_include(<glad/glad.h>)
#include <glad/glad.h>
#elif __has_include(<GL/glew.h>)
#include <GL/glew.h>
#endif

// === Hook these to YOUR project’s primitive draw calls =======================
// Search your codebase for existing functions/VAOs and map them here.
// Common names in CS330 templates are things like DrawCube(), RenderCube(), etc.
void RenderCube();     // <-- replace if your project uses a different name
void RenderCylinder(); // <-- replace if your project uses a different name

inline void DrawUnitBox() { RenderCube(); }
inline void DrawUnitCylinder() { RenderCylinder(); }
// ============================================================================

// Uniform helpers (assume active shader has "model" and "objectColor")
inline void SetModelMatrixUniform(const glm::mat4& M) {
    GLint prog = 0;
    glGetIntegerv(GL_CURRENT_PROGRAM, &prog);
    if (prog != 0) {
        GLint loc = glGetUniformLocation(prog, "model");
        if (loc >= 0) glUniformMatrix4fv(loc, 1, GL_FALSE, &M[0][0]);
    }
}

inline void SetColorUniform(const glm::vec3& c) {
    GLint prog = 0;
    glGetIntegerv(GL_CURRENT_PROGRAM, &prog);
    if (prog != 0) {
        GLint loc = glGetUniformLocation(prog, "objectColor");
        if (loc >= 0) glUniform3fv(loc, 1, &c[0]);
    }
}

// -------------------------- Bench definition -------------------------------
struct Bench {
    // Place the whole bench once
    glm::vec3 position = glm::vec3(0.0f, 0.0f, 0.0f);
    float     yawDegrees = 15.0f;  // rotate around Y for nicer view
    float     backTiltDeg = 10.0f;  // tilt backrest around X

    // Convenience
    static glm::mat4 S(float x, float y, float z) { return glm::scale(glm::mat4(1), glm::vec3(x, y, z)); }
    static glm::mat4 RX(float d) { return glm::rotate(glm::mat4(1), glm::radians(d), glm::vec3(1, 0, 0)); }
    static glm::mat4 RY(float d) { return glm::rotate(glm::mat4(1), glm::radians(d), glm::vec3(0, 1, 0)); }
    static glm::mat4 T(float x, float y, float z) { return glm::translate(glm::mat4(1), glm::vec3(x, y, z)); }

    glm::mat4 root() const { return T(position.x, position.y, position.z) * RY(yawDegrees); }

    // Parts (each uses: Model = Parent * Translate * Rotate * Scale)
    void drawSeatSlat(const glm::mat4& P, float y, float zOff) const {
        const float sx = 2.0f, sy = 0.05f, sz = 0.35f;
        glm::mat4 M = P * T(0.0f, y, zOff) * S(sx, sy, sz);
        SetModelMatrixUniform(M);
        DrawUnitBox();
    }

    void drawBackSlat(const glm::mat4& P, float y, float zOff) const {
        const float sx = 2.0f, sy = 0.05f, sz = 0.25f;
        glm::mat4 M = P * T(0.0f, y, zOff) * RX(-backTiltDeg) * S(sx, sy, sz);
        SetModelMatrixUniform(M);
        DrawUnitBox();
    }

    void drawLeg(const glm::mat4& P, float x) const {
        const float sx = 0.10f, sy = 0.55f, sz = 0.60f;
        glm::mat4 M = P * T(x, sy * 0.5f, 0.0f) * S(sx, sy, sz);
        SetModelMatrixUniform(M);
        DrawUnitBox();
    }

    void drawArmCap(const glm::mat4& P, float x) const {
        const float sx = 0.20f, sy = 0.05f, sz = 0.50f;
        const float legH = 0.55f;
        glm::mat4 M = P * T(x, legH + sy * 0.5f, 0.0f) * S(sx, sy, sz);
        SetModelMatrixUniform(M);
        DrawUnitBox();
    }

    void drawBolt(const glm::mat4& P, float x, float y, float z) const {
        // Unit cylinder assumed Y-up height=1, radius=1 → scale to tiny bolt
        const float r = 0.03f, h = 0.06f;
        glm::mat4 M = P * T(x, y, z) * S(r, h, r);
        SetModelMatrixUniform(M);
        DrawUnitCylinder();
    }

    void render() const {
        glm::mat4 B = root();

        // Wood color (optional debugging colors)
        SetColorUniform(glm::vec3(0.45f, 0.28f, 0.16f)); // brown

        // Seat (3 slats)
        drawSeatSlat(B, 0.50f, -0.10f);
        drawSeatSlat(B, 0.55f, 0.00f);
        drawSeatSlat(B, 0.50f, 0.10f);

        // Back (3 slats) slightly behind/above seat
        drawBackSlat(B, 0.85f, -0.20f);
        drawBackSlat(B, 0.95f, -0.20f);
        drawBackSlat(B, 1.05f, -0.20f);

        // Legs (2)
        drawLeg(B, -0.95f);
        drawLeg(B, 0.95f);

        // Arm caps (2)
        drawArmCap(B, -0.95f);
        drawArmCap(B, 0.95f);

        // Bolts (2 shapes total satisfied: boxes + cylinders)
        SetColorUniform(glm::vec3(0.65f, 0.65f, 0.68f)); // metal
        drawBolt(B, -0.95f, 0.40f, 0.25f);
        drawBolt(B, -0.95f, 0.40f, -0.25f);
        drawBolt(B, 0.95f, 0.40f, 0.25f);
        drawBolt(B, 0.95f, 0.40f, -0.25f);
    }
};
